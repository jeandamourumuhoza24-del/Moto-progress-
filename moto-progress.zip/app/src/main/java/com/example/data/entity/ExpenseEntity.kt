package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val category: String, // Lisansi, Amavuta, Repair, Amapine, Parking, Airtime, Food, Other
    val amountFrw: Double,
    val dateMillis: Long,
    val notes: String = ""
)
