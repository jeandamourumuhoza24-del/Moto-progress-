package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "savings")
data class SavingsEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val type: String, // "DEPOSIT" (Kuzigama) or "WITHDRAW" (Gukuramo)
    val amountFrw: Double,
    val dateMillis: Long,
    val notes: String = ""
)
