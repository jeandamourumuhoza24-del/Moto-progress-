package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "debts")
data class DebtEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val personName: String,
    val type: String, // "I_OWE" (Ideni mfite) or "OWES_ME" (Ideni bandimo)
    val amountFrw: Double,
    val dueDateMillis: Long = 0L,
    val isPaid: Boolean = false,
    val notes: String = ""
)
