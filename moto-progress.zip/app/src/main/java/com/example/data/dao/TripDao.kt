package com.example.data.dao

import androidx.room.*
import com.example.data.entity.TripEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {
    @Query("SELECT * FROM trips WHERE userId = :userId ORDER BY dateMillis DESC, id DESC")
    fun getAllTrips(userId: Int): Flow<List<TripEntity>>

    @Query("SELECT * FROM trips WHERE userId = :userId AND dateMillis >= :startTimeMillis AND dateMillis <= :endTimeMillis ORDER BY dateMillis DESC")
    fun getTripsInRange(userId: Int, startTimeMillis: Long, endTimeMillis: Long): Flow<List<TripEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: TripEntity)

    @Delete
    suspend fun deleteTrip(trip: TripEntity)
}
