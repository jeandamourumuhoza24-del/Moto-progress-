package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val amountFrw: Double,
    val dateMillis: Long,
    val timeString: String, // e.g. "08:30"
    val pickupLocation: String, // Aho yavuye
    val dropoffLocation: String, // Aho yajyaga
    val notes: String = ""
)
