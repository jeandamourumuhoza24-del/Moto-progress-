package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val title: String,
    val category: String, // "Moto service", "Amavuta", "Kuzigama", "Ibibina/Bills", "Amadeni", "Ibindi"
    val dueDateMillis: Long,
    val amountFrw: Double = 0.0,
    val isCompleted: Boolean = false,
    val notes: String = ""
)
