package com.example.data.dao

import androidx.room.*
import com.example.data.entity.MaintenanceEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MaintenanceDao {
    @Query("SELECT * FROM maintenance WHERE userId = :userId ORDER BY dateMillis DESC, id DESC")
    fun getAllMaintenance(userId: Int): Flow<List<MaintenanceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaintenance(maintenance: MaintenanceEntity)

    @Delete
    suspend fun deleteMaintenance(maintenance: MaintenanceEntity)
}
