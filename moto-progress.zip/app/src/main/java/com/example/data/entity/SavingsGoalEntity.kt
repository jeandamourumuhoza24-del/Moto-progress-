package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "savings_goals")
data class SavingsGoalEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val title: String, // e.g. "Gusana Moteur na Pneu" (Motorcycle Repair) or "Kugura Moto Yanjye Bwite" (Bike Ownership)
    val targetAmountFrw: Double,
    val currentAmountFrw: Double = 0.0,
    val targetDateMillis: Long,
    val category: String, // "REPAIR", "OWNERSHIP", "SPARE_PARTS", "INSURANCE"
    val isCompleted: Boolean = false,
    val notes: String = ""
)
