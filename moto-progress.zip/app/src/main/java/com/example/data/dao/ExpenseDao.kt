package com.example.data.dao

import androidx.room.*
import com.example.data.entity.ExpenseEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses WHERE userId = :userId ORDER BY dateMillis DESC, id DESC")
    fun getAllExpenses(userId: Int): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE userId = :userId AND dateMillis >= :startTimeMillis AND dateMillis <= :endTimeMillis ORDER BY dateMillis DESC")
    fun getExpensesInRange(userId: Int, startTimeMillis: Long, endTimeMillis: Long): Flow<List<ExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity)

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)
}
