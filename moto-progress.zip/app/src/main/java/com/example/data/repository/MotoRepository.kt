package com.example.data.repository

import com.example.data.dao.*
import com.example.data.entity.*
import kotlinx.coroutines.flow.Flow

class MotoRepository(
    private val userDao: UserDao,
    private val tripDao: TripDao,
    private val expenseDao: ExpenseDao,
    private val savingsDao: SavingsDao,
    private val maintenanceDao: MaintenanceDao,
    private val reminderDao: ReminderDao,
    private val debtDao: DebtDao,
    private val savingsGoalDao: SavingsGoalDao
) {
    // User
    suspend fun getUserByPhone(phone: String): UserEntity? = userDao.getUserByPhone(phone)
    fun getUserByIdFlow(id: Int): Flow<UserEntity?> = userDao.getUserByIdFlow(id)
    suspend fun getUserById(id: Int): UserEntity? = userDao.getUserById(id)
    suspend fun getLastLoggedInUser(): UserEntity? = userDao.getLastLoggedInUser()
    suspend fun insertUser(user: UserEntity): Long = userDao.insertUser(user)
    suspend fun updateUser(user: UserEntity) = userDao.updateUser(user)

    // Trips
    fun getAllTrips(userId: Int): Flow<List<TripEntity>> = tripDao.getAllTrips(userId)
    suspend fun insertTrip(trip: TripEntity) = tripDao.insertTrip(trip)
    suspend fun deleteTrip(trip: TripEntity) = tripDao.deleteTrip(trip)

    // Expenses
    fun getAllExpenses(userId: Int): Flow<List<ExpenseEntity>> = expenseDao.getAllExpenses(userId)
    suspend fun insertExpense(expense: ExpenseEntity) = expenseDao.insertExpense(expense)
    suspend fun deleteExpense(expense: ExpenseEntity) = expenseDao.deleteExpense(expense)

    // Savings
    fun getAllSavings(userId: Int): Flow<List<SavingsEntity>> = savingsDao.getAllSavings(userId)
    suspend fun insertSavings(savings: SavingsEntity) = savingsDao.insertSavings(savings)
    suspend fun deleteSavings(savings: SavingsEntity) = savingsDao.deleteSavings(savings)

    // Maintenance
    fun getAllMaintenance(userId: Int): Flow<List<MaintenanceEntity>> = maintenanceDao.getAllMaintenance(userId)
    suspend fun insertMaintenance(maintenance: MaintenanceEntity) = maintenanceDao.insertMaintenance(maintenance)
    suspend fun deleteMaintenance(maintenance: MaintenanceEntity) = maintenanceDao.deleteMaintenance(maintenance)

    // Reminders
    fun getAllReminders(userId: Int): Flow<List<ReminderEntity>> = reminderDao.getAllReminders(userId)
    suspend fun insertReminder(reminder: ReminderEntity) = reminderDao.insertReminder(reminder)
    suspend fun updateReminder(reminder: ReminderEntity) = reminderDao.updateReminder(reminder)
    suspend fun deleteReminder(reminder: ReminderEntity) = reminderDao.deleteReminder(reminder)

    // Debts
    fun getAllDebts(userId: Int): Flow<List<DebtEntity>> = debtDao.getAllDebts(userId)
    suspend fun insertDebt(debt: DebtEntity) = debtDao.insertDebt(debt)
    suspend fun updateDebt(debt: DebtEntity) = debtDao.updateDebt(debt)
    suspend fun deleteDebt(debt: DebtEntity) = debtDao.deleteDebt(debt)

    // Savings Goals (Motorcycle Repairs & Ownership)
    fun getAllSavingsGoals(userId: Int): Flow<List<SavingsGoalEntity>> = savingsGoalDao.getAllSavingsGoals(userId)
    suspend fun insertSavingsGoal(goal: SavingsGoalEntity): Long = savingsGoalDao.insertSavingsGoal(goal)
    suspend fun updateSavingsGoal(goal: SavingsGoalEntity) = savingsGoalDao.updateSavingsGoal(goal)
    suspend fun deleteSavingsGoal(goal: SavingsGoalEntity) = savingsGoalDao.deleteSavingsGoal(goal)
}
