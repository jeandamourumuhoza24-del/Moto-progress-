package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val fullName: String,
    val phoneNumber: String,
    val pinCode: String,
    val plateNumber: String,
    val monthlyGoalFrw: Double = 300000.0,
    val currentOdometerKm: Int = 12000,
    val createdAtMillis: Long = System.currentTimeMillis()
)
