package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "maintenance")
data class MaintenanceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val type: String, // "Amavuta ya moto", "Amapine", "Gusana / Repair", "Service rusange", "Ibindi"
    val dateMillis: Long,
    val odometerKm: Int,
    val costFrw: Double,
    val nextDueKm: Int = 0,
    val nextDueDateMillis: Long = 0L,
    val notes: String = ""
)
