package com.example.data.dao

import androidx.room.*
import com.example.data.entity.SavingsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SavingsDao {
    @Query("SELECT * FROM savings WHERE userId = :userId ORDER BY dateMillis DESC, id DESC")
    fun getAllSavings(userId: Int): Flow<List<SavingsEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavings(savings: SavingsEntity)

    @Delete
    suspend fun deleteSavings(savings: SavingsEntity)
}
