package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.entity.DebtEntity
import com.example.data.entity.MaintenanceEntity
import com.example.data.entity.ReminderEntity
import com.example.data.entity.UserEntity
import com.example.ui.theme.MotoGreenSuccess
import com.example.ui.theme.MotoRedExpense
import com.example.ui.theme.MotoYellowPrimary
import com.example.util.Formatters

@Composable
fun MotoScreen(
    user: UserEntity,
    maintenanceList: List<MaintenanceEntity>,
    remindersList: List<ReminderEntity>,
    debtsList: List<DebtEntity>,
    onAddMaintenanceClick: () -> Unit,
    onAddReminderClick: () -> Unit,
    onAddDebtClick: () -> Unit,
    onToggleReminder: (ReminderEntity) -> Unit,
    onToggleDebtPaid: (DebtEntity) -> Unit,
    onDeleteReminder: (ReminderEntity) -> Unit,
    onDeleteDebt: (DebtEntity) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Maintenance, 1: Reminders, 2: Debts

    val lastOilChange = maintenanceList.firstOrNull { it.type.contains("Amavuta", ignoreCase = true) }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    when (selectedTab) {
                        0 -> onAddMaintenanceClick()
                        1 -> onAddReminderClick()
                        2 -> onAddDebtClick()
                    }
                },
                containerColor = MotoYellowPrimary,
                contentColor = Color.Black,
                icon = { Icon(Icons.Default.Add, contentDescription = "Add") },
                text = {
                    Text(
                        when (selectedTab) {
                            0 -> "Andika Service ya Moto"
                            1 -> "Andika Kwibutswa"
                            else -> "Andika Ideni"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                modifier = Modifier.testTag("fab_moto_screen")
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "Moto Yanjye & Ibiporogaramuwe",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Gucunga umutekano w'ikinyabiziga no kwibuka gahunda zawe",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
            }

            // Tabs Header
            item {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Service & Moto", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Kwibutswa (${remindersList.count { !it.isCompleted }})", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Amadeni (${debtsList.count { !it.isPaid }})", fontWeight = FontWeight.Bold) }
                    )
                }
            }

            when (selectedTab) {
                0 -> {
                    // Maintenance Section
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text(
                                    text = "Incamake ya Service iheruka",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("Amavuta ya Moto yaherukaga", style = MaterialTheme.typography.labelSmall)
                                        Text(
                                            text = if (lastOilChange != null) "${lastOilChange.odometerKm} km (${Formatters.formatDateShort(lastOilChange.dateMillis)})" else "Nta fishi ihari",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Amavuta y'ubutaha (Next due)", style = MaterialTheme.typography.labelSmall)
                                        Text(
                                            text = if (lastOilChange != null && lastOilChange.nextDueKm > 0) "${lastOilChange.nextDueKm} km" else "16,000 km",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = MotoYellowPrimary
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Irometero z'uyu munsi: ${user.currentOdometerKm} km",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    item {
                        Text(
                            text = "Amateka ya Service & Isana (${maintenanceList.size})",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    if (maintenanceList.isEmpty()) {
                        item {
                            Text(
                                text = "Nta service cyangwa isana rya moto rirandikwa.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    } else {
                        items(maintenanceList) { item ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier.size(40.dp).clip(CircleShape).background(MotoYellowPrimary.copy(alpha = 0.2f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Build, contentDescription = null, tint = MotoYellowPrimary)
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = item.type,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                            )
                                            Text(
                                                text = "${Formatters.formatDateShort(item.dateMillis)} | ${item.odometerKm} km",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                            )
                                            if (item.notes.isNotBlank()) {
                                                Text(
                                                    text = item.notes,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                    }

                                    Text(
                                        text = Formatters.formatFrw(item.costFrw),
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MotoRedExpense
                                    )
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // Reminders Section
                    item {
                        Text(
                            text = "Gahunda Zo Kwibutswa (${remindersList.size})",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    if (remindersList.isEmpty()) {
                        item {
                            Text(
                                text = "Nta gahunda bihari zo kwibutswa.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    } else {
                        items(remindersList) { reminder ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Checkbox(
                                            checked = reminder.isCompleted,
                                            onCheckedChange = { onToggleReminder(reminder) }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = reminder.title,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                            )
                                            Text(
                                                text = "${reminder.category} | ${Formatters.formatDateShort(reminder.dueDateMillis)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                            )
                                        }
                                    }

                                    IconButton(onClick = { onDeleteReminder(reminder) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f))
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // Debts Section
                    item {
                        Text(
                            text = "Amadeni N'Abantu Bandimo (${debtsList.size})",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    if (debtsList.isEmpty()) {
                        item {
                            Text(
                                text = "Nta madeni arandikwa.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    } else {
                        items(debtsList) { debt ->
                            val isIowe = debt.type == "I_OWE"
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Checkbox(
                                            checked = debt.isPaid,
                                            onCheckedChange = { onToggleDebtPaid(debt) }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = debt.personName,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                            )
                                            Text(
                                                text = if (isIowe) "Ideni Mfite (Nishyura)" else "Bandimo (Banishyura)",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (isIowe) MotoRedExpense else MotoGreenSuccess,
                                                fontWeight = FontWeight.Bold
                                            )
                                            if (debt.notes.isNotBlank()) {
                                                Text(
                                                    text = debt.notes,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                                )
                                            }
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = Formatters.formatFrw(debt.amountFrw),
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = if (isIowe) MotoRedExpense else MotoGreenSuccess
                                        )
                                        IconButton(onClick = { onDeleteDebt(debt) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
