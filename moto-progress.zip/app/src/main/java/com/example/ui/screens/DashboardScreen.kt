package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.*
import com.example.ui.components.DailyIncomeExpenseChart
import com.example.ui.components.StatCard
import com.example.ui.theme.*
import com.example.util.Formatters

@Composable
fun DashboardScreen(
    user: UserEntity,
    trips: List<TripEntity>,
    expenses: List<ExpenseEntity>,
    savings: List<SavingsEntity>,
    reminders: List<ReminderEntity>,
    debts: List<DebtEntity>,
    onAddTripClick: () -> Unit,
    onAddExpenseClick: () -> Unit,
    onToggleReminder: (ReminderEntity) -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToProfile: () -> Unit
) {
    val now = System.currentTimeMillis()

    // Calculations
    val todayTrips = trips.filter { Formatters.isSameDay(it.dateMillis, now) }
    val todayIncome = todayTrips.sumOf { it.amountFrw }

    val todayExpensesList = expenses.filter { Formatters.isSameDay(it.dateMillis, now) }
    val todayExpensesTotal = todayExpensesList.sumOf { it.amountFrw }

    val todayFuel = todayExpensesList
        .filter { it.category.contains("Lisansi", ignoreCase = true) }
        .sumOf { it.amountFrw }

    val todayProfit = todayIncome - todayExpensesTotal

    val totalSavings = savings.sumOf {
        if (it.type == "DEPOSIT") it.amountFrw else -it.amountFrw
    }.coerceAtLeast(0.0)

    val monthlyGoal = user.monthlyGoalFrw
    val goalPercent = if (monthlyGoal > 0) ((totalSavings / monthlyGoal) * 100).toInt().coerceIn(0, 100) else 0

    val unpaidDebts = debts.filter { !it.isPaid }
    val totalDebtAmount = unpaidDebts.filter { it.type == "I_OWE" }.sumOf { it.amountFrw }

    val smartAdviceList = remember(trips, expenses, monthlyGoal, totalSavings) {
        Formatters.generateSmartAdvice(trips, expenses, monthlyGoal, totalSavings)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Muraho, ${user.fullName}!",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TwoWheeler,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Plaque: ${user.plateNumber} | ${Formatters.formatDateKinyarwanda(now)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }

                    IconButton(
                        onClick = onNavigateToProfile,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Profile",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }

        // Quick Entry Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onAddTripClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("dashboard_add_trip_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MotoGreenSuccess)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Andika Urugendo", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onAddExpenseClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("dashboard_add_expense_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MotoRedExpense)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Andika Yasohotse", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Smart Advisor Card ("Inama y'uyu munsi")
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MotoTealAccent.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = null,
                                tint = MotoTealAccent,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Inama y'uyu munsi",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        TextButton(onClick = onNavigateToReports) {
                            Text("Iraporo yose", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (smartAdviceList.isNotEmpty()) {
                        smartAdviceList.forEach { advice ->
                            Row(
                                modifier = Modifier.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text("• ", fontWeight = FontWeight.Bold, color = MotoTealAccent)
                                Text(
                                    text = advice,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "Andika ingendo n'amafaranga nasohoye kugira ngo ubone inama z'ikoranabuhanga.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }

        // Main Financial Cards Grid / Column
        item {
            Text(
                text = "Incamake y'Uyu Munsi",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        item {
            StatCard(
                title = "Amafaranga winjije uyu munsi",
                value = Formatters.formatFrw(todayIncome),
                subtitle = "Trips: ${todayTrips.size} | Avg: ${if (todayTrips.isNotEmpty()) Formatters.formatFrw(todayIncome / todayTrips.size) else "0 Frw"}",
                icon = Icons.Default.TrendingUp,
                iconBgColor = MotoGreenSuccess
            )
        }

        item {
            StatCard(
                title = "Amafaranga wakoresheje uyu munsi",
                value = Formatters.formatFrw(todayExpensesTotal),
                subtitle = "Lisansi wakoresheje: ${Formatters.formatFrw(todayFuel)}",
                icon = Icons.Default.TrendingDown,
                iconBgColor = MotoRedExpense
            )
        }

        item {
            StatCard(
                title = "Inyungu isigaye",
                value = Formatters.formatFrw(todayProfit),
                subtitle = if (todayProfit >= 0) "Inyungu nziza uyu munsi" else "Igihombo uyu munsi",
                icon = Icons.Default.AccountBalanceWallet,
                iconBgColor = if (todayProfit >= 0) MotoYellowPrimary else MotoRedExpense,
                iconColor = Color.Black
            )
        }

        item {
            StatCard(
                title = "Amafaranga wazigamye",
                value = Formatters.formatFrw(totalSavings),
                subtitle = "Intego y'ukwezi: ${Formatters.formatFrw(monthlyGoal)} ($goalPercent%)",
                icon = Icons.Default.Savings,
                iconBgColor = MotoBlueInfo
            )
        }

        // Monthly Goal Progress Bar
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Intego y'ukwezi ($goalPercent%)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${Formatters.formatFrw(totalSavings)} / ${Formatters.formatFrw(monthlyGoal)}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { (goalPercent / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = MotoYellowPrimary,
                        trackColor = MaterialTheme.colorScheme.surface
                    )
                }
            }
        }

        // Daily Income vs Expense Visualization Chart
        item {
            DailyIncomeExpenseChart(trips = trips, expenses = expenses)
        }

        // Debts Banner if any
        if (totalDebtAmount > 0) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MotoRedExpense.copy(alpha = 0.15f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MotoRedExpense
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Amadeni ufite ayo kwishyura",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Muri rusange ufite amadeni ya ${Formatters.formatFrw(totalDebtAmount)}.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Reminders Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Ibiporogaramuwe (Reminders)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${reminders.count { !it.isCompleted }} Isigaye",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        if (reminders.isEmpty()) {
            item {
                Text(
                    text = "Nta bibukirwa bihari.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        } else {
            items(reminders.take(4)) { reminder ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (reminder.isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Checkbox(
                                checked = reminder.isCompleted,
                                onCheckedChange = { onToggleReminder(reminder) }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = reminder.title,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = if (reminder.isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f) else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${reminder.category} | Itariki: ${Formatters.formatDateShort(reminder.dueDateMillis)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        }

                        if (reminder.amountFrw > 0) {
                            Text(
                                text = Formatters.formatFrw(reminder.amountFrw),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MotoYellowPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}
