package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MotoYellowPrimary = Color(0xFFEAB308)
val MotoYellowDark = Color(0xFFCA8A04)
val MotoTealAccent = Color(0xFF0D9488)
val MotoGreenSuccess = Color(0xFF10B981)
val MotoRedExpense = Color(0xFFEF4444)
val MotoBlueInfo = Color(0xFF0284C7)

val DarkSurface = Color(0xFF121B22)
val DarkBackground = Color(0xFF0B1015)
val DarkCardBg = Color(0xFF1E293B)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightCardBg = Color(0xFFF1F5F9)

