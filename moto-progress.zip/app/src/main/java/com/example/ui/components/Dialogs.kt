package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTripDialog(
    onDismiss: () -> Unit,
    onSave: (amount: Double, pickup: String, dropoff: String, notes: String) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var pickupText by remember { mutableStateOf("") }
    var dropoffText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Andika Amafaranga Winjije",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; errorMsg = null },
                    label = { Text("Amafaranga umugenzi yishyuye (Frw)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("trip_amount_input")
                )

                OutlinedTextField(
                    value = pickupText,
                    onValueChange = { pickupText = it },
                    label = { Text("Aho yavuye (Shema/Agace)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("trip_pickup_input")
                )

                OutlinedTextField(
                    value = dropoffText,
                    onValueChange = { dropoffText = it },
                    label = { Text("Aho yajyaga (Shema/Agace)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("trip_dropoff_input")
                )

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Ibindi bisobanuro (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Text(
                        text = errorMsg!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt <= 0) {
                        errorMsg = "Andika ingano y'amafaranga icyo ari cyo cyose."
                    } else {
                        onSave(amt, pickupText, dropoffText, notesText)
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("save_trip_button")
            ) {
                Text("Bika")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Hagarika")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddExpenseDialog(
    onDismiss: () -> Unit,
    onSave: (category: String, amount: Double, notes: String) -> Unit
) {
    val categories = listOf(
        "Lisansi", "Amavuta ya moto", "Repair", "Amapine", "Parking", "Airtime/data", "Food", "Other expenses"
    )

    var selectedCategory by remember { mutableStateOf(categories[0]) }
    var amountText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var expandedDropdown by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Andika Amafaranga Nasohoye", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ExposedDropdownMenuBox(
                    expanded = expandedDropdown,
                    onExpandedChange = { expandedDropdown = !expandedDropdown }
                ) {
                    OutlinedTextField(
                        value = selectedCategory,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Ubwoko bw'amafaranga (Category)") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedDropdown,
                        onDismissRequest = { expandedDropdown = false }
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat) },
                                onClick = {
                                    selectedCategory = cat
                                    expandedDropdown = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; errorMsg = null },
                    label = { Text("Amafaranga yakoreshejwe (Frw)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("expense_amount_input")
                )

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Ibisobanuro (e.g. Station, Umukanishi)") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt <= 0) {
                        errorMsg = "Andika amafaranga neza."
                    } else {
                        onSave(selectedCategory, amt, notesText)
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("save_expense_button")
            ) {
                Text("Bika")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hagarika") }
        }
    )
}

@Composable
fun AddSavingsDialog(
    onDismiss: () -> Unit,
    onSave: (type: String, amount: Double, notes: String) -> Unit
) {
    var isDeposit by remember { mutableStateOf(true) }
    var amountText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Kuzigama / Gukuramo", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    FilterChip(
                        selected = isDeposit,
                        onClick = { isDeposit = true },
                        label = { Text("Kuzigama (+)") }
                    )
                    FilterChip(
                        selected = !isDeposit,
                        onClick = { isDeposit = false },
                        label = { Text("Gukuramo (-)") }
                    )
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; errorMsg = null },
                    label = { Text("Amafaranga (Frw)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("savings_amount_input")
                )

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Ibisobanuro (e.g., Ejo Heza, Mobile Money)") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt <= 0) {
                        errorMsg = "Andika amafaranga ubona ko ari yo."
                    } else {
                        onSave(if (isDeposit) "DEPOSIT" else "WITHDRAW", amt, notesText)
                        onDismiss()
                    }
                }
            ) {
                Text("Bika")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hagarika") }
        }
    )
}

@Composable
fun EditGoalDialog(
    currentGoal: Double,
    onDismiss: () -> Unit,
    onSave: (newGoal: Double) -> Unit
) {
    var goalText by remember { mutableStateOf(currentGoal.toInt().toString()) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set Intego y'Ukwezi", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Text(
                    "Andika ingano y'amafaranga wifuza kuzigama muri uku kwezi:",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = goalText,
                    onValueChange = { goalText = it; errorMsg = null },
                    label = { Text("Intego (Frw)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("goal_amount_input")
                )
                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val g = goalText.toDoubleOrNull()
                if (g == null || g <= 0) {
                    errorMsg = "Andika intego nziza y'amafaranga."
                } else {
                    onSave(g)
                    onDismiss()
                }
            }) { Text("Hindura") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hagarika") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMaintenanceDialog(
    onDismiss: () -> Unit,
    onSave: (type: String, cost: Double, odometer: Int, nextKm: Int, notes: String) -> Unit
) {
    val types = listOf("Amavuta ya moto", "Amapine", "Gusana / Repair", "Service rusange", "Ibindi")
    var selectedType by remember { mutableStateOf(types[0]) }
    var costText by remember { mutableStateOf("") }
    var odometerText by remember { mutableStateOf("") }
    var nextKmText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var expandedDropdown by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Andika Isana / Service ya Moto", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ExposedDropdownMenuBox(
                    expanded = expandedDropdown,
                    onExpandedChange = { expandedDropdown = !expandedDropdown }
                ) {
                    OutlinedTextField(
                        value = selectedType,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Ubwoko bwa Service") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedDropdown,
                        onDismissRequest = { expandedDropdown = false }
                    ) {
                        types.forEach { t ->
                            DropdownMenuItem(text = { Text(t) }, onClick = { selectedType = t; expandedDropdown = false })
                        }
                    }
                }

                OutlinedTextField(
                    value = costText,
                    onValueChange = { costText = it; errorMsg = null },
                    label = { Text("Igiciro / Amafaranga (Frw)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = odometerText,
                    onValueChange = { odometerText = it },
                    label = { Text("Irometero z'uyu munsi (Km, e.g. 15400)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = nextKmText,
                    onValueChange = { nextKmText = it },
                    label = { Text("Irometero z'ubutaha (Km, e.g. 16500)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Ibisobanuro (Garage, ibipande nshya)") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val c = costText.toDoubleOrNull() ?: 0.0
                val odo = odometerText.toIntOrNull() ?: 0
                val nextK = nextKmText.toIntOrNull() ?: 0
                onSave(selectedType, c, odo, nextK, notesText)
                onDismiss()
            }) { Text("Bika") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hagarika") }
        }
    )
}

@Composable
fun AddReminderDialog(
    onDismiss: () -> Unit,
    onSave: (title: String, category: String, daysFromNow: Int, amount: Double, notes: String) -> Unit
) {
    var titleText by remember { mutableStateOf("") }
    var categoryText by remember { mutableStateOf("Service ya Moto") }
    var daysText by remember { mutableStateOf("3") }
    var amountText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Andika Kwibutswa (Reminder)", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it; errorMsg = null },
                    label = { Text("Umutwe w'icyo wibutswa (Title)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = categoryText,
                    onValueChange = { categoryText = it },
                    label = { Text("Icyiciro (e.g. Amavuta, Kuzigama, Bills)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = daysText,
                    onValueChange = { daysText = it },
                    label = { Text("Iminsi isigaye (e.g. 2 for ejo bundi)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amafaranga akenewe (If any, Frw)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Ibisobanuro") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (titleText.isBlank()) {
                    errorMsg = "Andika umutwe w'icyo wibutswa."
                } else {
                    val days = daysText.toIntOrNull() ?: 1
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    onSave(titleText, categoryText, days, amt, notesText)
                    onDismiss()
                }
            }) { Text("Bika") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hagarika") }
        }
    )
}

@Composable
fun AddDebtDialog(
    onDismiss: () -> Unit,
    onSave: (personName: String, type: String, amount: Double, daysFromNow: Int, notes: String) -> Unit
) {
    var personText by remember { mutableStateOf("") }
    var isIowe by remember { mutableStateOf(true) }
    var amountText by remember { mutableStateOf("") }
    var daysText by remember { mutableStateOf("7") }
    var notesText by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Andika Ideni", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = personText,
                    onValueChange = { personText = it; errorMsg = null },
                    label = { Text("Izina ry'umuntu (Person)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    FilterChip(
                        selected = isIowe,
                        onClick = { isIowe = true },
                        label = { Text("Ideni mfite (Nishyura)") }
                    )
                    FilterChip(
                        selected = !isIowe,
                        onClick = { isIowe = false },
                        label = { Text("Bandimo (Banishyura)") }
                    )
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; errorMsg = null },
                    label = { Text("Amafaranga y'ideni (Frw)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = daysText,
                    onValueChange = { daysText = it },
                    label = { Text("Itariki yo kwishyura (Iminsi isigaye)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Ibisobanuro") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val amt = amountText.toDoubleOrNull()
                if (personText.isBlank() || amt == null || amt <= 0) {
                    errorMsg = "Andika izina n'amafaranga neza."
                } else {
                    val days = daysText.toIntOrNull() ?: 7
                    onSave(personText, if (isIowe) "I_OWE" else "OWES_ME", amt, days, notesText)
                    onDismiss()
                }
            }) { Text("Bika") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hagarika") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSavingsGoalDialog(
    onDismiss: () -> Unit,
    onSave: (title: String, targetAmount: Double, initialAmount: Double, daysFromNow: Int, category: String, notes: String) -> Unit
) {
    var titleText by remember { mutableStateOf("") }
    var targetText by remember { mutableStateOf("") }
    var initialText by remember { mutableStateOf("") }
    var daysText by remember { mutableStateOf("60") }
    var selectedCategory by remember { mutableStateOf("REPAIR") } // "REPAIR" or "OWNERSHIP"
    var notesText by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Shyiraho Intego y'Ibyazigama", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it; errorMsg = null },
                    label = { Text("Izina ry'intego (e.g. Gusana Moto / Kugura Moto)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("savings_goal_title_input")
                )

                Text("Icyiciro (Category):", style = MaterialTheme.typography.bodySmall)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedCategory == "REPAIR",
                        onClick = { selectedCategory = "REPAIR" },
                        label = { Text("Gusana Moto (Repair)") }
                    )
                    FilterChip(
                        selected = selectedCategory == "OWNERSHIP",
                        onClick = { selectedCategory = "OWNERSHIP" },
                        label = { Text("Kugura Moto (Ownership)") }
                    )
                }

                OutlinedTextField(
                    value = targetText,
                    onValueChange = { targetText = it; errorMsg = null },
                    label = { Text("Intego y'Amafaranga (Target Frw)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("savings_goal_target_input")
                )

                OutlinedTextField(
                    value = initialText,
                    onValueChange = { initialText = it },
                    label = { Text("Ayo ufite ubu (Initial Amount Frw)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = daysText,
                    onValueChange = { daysText = it },
                    label = { Text("Aramara iminsi ingana iki? (Target Days)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Ibindi bisobanuro (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val targetAmt = targetText.toDoubleOrNull()
                    val initAmt = initialText.toDoubleOrNull() ?: 0.0
                    val days = daysText.toIntOrNull() ?: 60
                    if (titleText.isBlank() || targetAmt == null || targetAmt <= 0) {
                        errorMsg = "Uzuza izina n'intego y'amafaranga neza."
                    } else {
                        onSave(titleText, targetAmt, initAmt, days, selectedCategory, notesText)
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("save_savings_goal_button")
            ) { Text("Bika Intego") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hagarika") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContributeSavingsGoalDialog(
    goalTitle: String,
    remainingAmountFrw: Double,
    onDismiss: () -> Unit,
    onSave: (amount: Double) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Kongera ku Intego: $goalTitle", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Ayo ukeneye ngo wuzuze iyi ntego: ${com.example.util.Formatters.formatFrw(remainingAmountFrw)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; errorMsg = null },
                    label = { Text("Amafaranga wazigamye uyu munsi (Frw)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("contribute_amount_input")
                )

                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt <= 0) {
                        errorMsg = "Andika amafaranga meza uzigama."
                    } else {
                        onSave(amt)
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("save_contribution_button")
            ) { Text("Ongera Amafaranga") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hagarika") }
        }
    )
}
