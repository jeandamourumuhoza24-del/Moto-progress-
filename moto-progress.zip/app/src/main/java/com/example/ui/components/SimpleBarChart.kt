package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MotoRedExpense
import com.example.ui.theme.MotoYellowPrimary

data class BarChartItem(
    val label: String,
    val value: Double,
    val color: Color = MotoYellowPrimary
)

@Composable
fun SimpleBarChart(
    items: List<BarChartItem>,
    modifier: Modifier = Modifier,
    maxHeightDp: Int = 140
) {
    if (items.isEmpty()) return

    val maxValue = items.maxOfOrNull { it.value }?.coerceAtLeast(1.0) ?: 1.0

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(maxHeightDp.dp)
            .padding(top = 16.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
    ) {
        items.forEach { item ->
            val fraction = (item.value / maxValue).toFloat().coerceIn(0.05f, 1f)
            val animatedHeightFraction by animateFloatAsState(targetValue = fraction, label = "barHeight")

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                // Value text above bar
                if (item.value > 0) {
                    Text(
                        text = if (item.value >= 1000) "${(item.value / 1000).toInt()}k" else "${item.value.toInt()}",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Bar container
                Box(
                    modifier = Modifier
                        .width(20.dp)
                        .weight(1f, fill = false)
                        .fillMaxHeight(animatedHeightFraction)
                        .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                        .background(item.color)
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Label below bar
                Text(
                    text = item.label,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun CategoryProgressRow(
    category: String,
    amountFrw: Double,
    totalExpenses: Double,
    color: Color = MotoRedExpense
) {
    val percentage = if (totalExpenses > 0) (amountFrw / totalExpenses) else 0.0
    val animPercent by animateFloatAsState(targetValue = percentage.toFloat(), label = "progress")

    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = category,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "${com.example.util.Formatters.formatFrw(amountFrw)} (${(percentage * 100).toInt()}%)",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(animPercent)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color)
            )
        }
    }
}
