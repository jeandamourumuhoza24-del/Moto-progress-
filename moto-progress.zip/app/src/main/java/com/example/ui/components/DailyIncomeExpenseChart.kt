package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.ExpenseEntity
import com.example.data.entity.TripEntity
import com.example.ui.theme.MotoGreenSuccess
import com.example.ui.theme.MotoRedExpense
import com.example.ui.theme.MotoYellowPrimary
import com.example.util.Formatters
import java.util.Calendar

data class DailySummaryItem(
    val dayLabel: String,
    val fullDate: String,
    val incomeFrw: Double,
    val expenseFrw: Double,
    val netProfitFrw: Double,
    val tripCount: Int,
    val dateMillis: Long
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyIncomeExpenseChart(
    trips: List<TripEntity>,
    expenses: List<ExpenseEntity>,
    modifier: Modifier = Modifier
) {
    var selectedDaysRange by remember { mutableIntStateOf(7) } // 7, 14, or 30 days
    var selectedDayIndex by remember { mutableStateOf<Int?>(null) }

    // Prepare data for the selected range
    val dailySummaries = remember(trips, expenses, selectedDaysRange) {
        val list = mutableListOf<DailySummaryItem>()
        val dayNames = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        val shortDayNamesRw = arrayOf("Mye", "Mbe", "Kab", "Gat", "Kan", "Gtu", "Cyu")

        for (i in (selectedDaysRange - 1) downTo 0) {
            val cal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -i)
            }
            val dayMills = cal.timeInMillis
            val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1

            val dayTrips = trips.filter { Formatters.isSameDay(it.dateMillis, dayMills) }
            val dayIncome = dayTrips.sumOf { it.amountFrw }
            val dayExpenses = expenses.filter { Formatters.isSameDay(it.dateMillis, dayMills) }.sumOf { it.amountFrw }

            val label = if (selectedDaysRange == 7) shortDayNamesRw[dayOfWeek] else "${cal.get(Calendar.DAY_OF_MONTH)}/${cal.get(Calendar.MONTH) + 1}"
            val fullDateStr = Formatters.formatDateShort(dayMills)

            list.add(
                DailySummaryItem(
                    dayLabel = label,
                    fullDate = fullDateStr,
                    incomeFrw = dayIncome,
                    expenseFrw = dayExpenses,
                    netProfitFrw = dayIncome - dayExpenses,
                    tripCount = dayTrips.size,
                    dateMillis = dayMills
                )
            )
        }
        list
    }

    val maxVal = remember(dailySummaries) {
        val maxInc = dailySummaries.maxOfOrNull { it.incomeFrw } ?: 0.0
        val maxExp = dailySummaries.maxOfOrNull { it.expenseFrw } ?: 0.0
        maxOf(maxInc, maxExp, 1000.0)
    }

    val totalIncomeInRange = remember(dailySummaries) { dailySummaries.sumOf { it.incomeFrw } }
    val totalExpensesInRange = remember(dailySummaries) { dailySummaries.sumOf { it.expenseFrw } }
    val avgDailyProfit = remember(dailySummaries) {
        if (dailySummaries.isNotEmpty()) (totalIncomeInRange - totalExpensesInRange) / dailySummaries.size else 0.0
    }

    Card(
        modifier = modifier.fillMaxWidth().testTag("daily_income_expense_chart_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header with range toggle buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.BarChart,
                        contentDescription = "Chart",
                        tint = MotoYellowPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Iraporo y'Umunsi na Umunsi",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                // Segmented buttons (7, 14, 30 days)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf(7 to "7D", 14 to "14D", 30 to "30D").forEach { (days, label) ->
                        FilterChip(
                            selected = selectedDaysRange == days,
                            onClick = {
                                selectedDaysRange = days
                                selectedDayIndex = null
                            },
                            label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            modifier = Modifier.height(30.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Stats Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(MotoGreenSuccess))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Yinjiye: ${Formatters.formatFrw(totalIncomeInRange)}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(MotoRedExpense))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Yasohotse: ${Formatters.formatFrw(totalExpensesInRange)}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Bar Chart Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    dailySummaries.forEachIndexed { index, item ->
                        val isSelected = selectedDayIndex == index
                        val incFraction = (item.incomeFrw / maxVal).toFloat().coerceIn(0.04f, 1f)
                        val expFraction = (item.expenseFrw / maxVal).toFloat().coerceIn(0.04f, 1f)

                        val animIncHeight by animateFloatAsState(targetValue = incFraction, label = "incHeight")
                        val animExpHeight by animateFloatAsState(targetValue = expFraction, label = "expHeight")

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else Color.Transparent)
                                .clickable { selectedDayIndex = if (isSelected) null else index }
                                .padding(horizontal = 2.dp, vertical = 4.dp)
                        ) {
                            // Net indicator dot
                            if (item.incomeFrw > 0 || item.expenseFrw > 0) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (item.netProfitFrw >= 0) MotoGreenSuccess else MotoRedExpense)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                            }

                            // Paired Bars (Income & Expense)
                            Row(
                                modifier = Modifier
                                    .weight(1f, fill = false)
                                    .fillMaxHeight(),
                                horizontalArrangement = Arrangement.spacedBy(2.dp),
                                verticalAlignment = Alignment.Bottom
                            ) {
                                // Income Bar (Green)
                                Box(
                                    modifier = Modifier
                                        .width(if (selectedDaysRange > 14) 4.dp else 8.dp)
                                        .fillMaxHeight(animIncHeight)
                                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                        .background(MotoGreenSuccess)
                                )

                                // Expense Bar (Red)
                                Box(
                                    modifier = Modifier
                                        .width(if (selectedDaysRange > 14) 4.dp else 8.dp)
                                        .fillMaxHeight(animExpHeight)
                                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                        .background(MotoRedExpense)
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Day Label
                            Text(
                                text = item.dayLabel,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = if (selectedDaysRange > 14) 9.sp else 11.sp),
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Selected Day Detail Panel or Average Profit Tip
            AnimatedVisibility(visible = selectedDayIndex != null) {
                selectedDayIndex?.let { idx ->
                    val dayItem = dailySummaries.getOrNull(idx)
                    if (dayItem != null) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("selected_day_detail_card"),
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(12.dp),
                            tonalElevation = 2.dp
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Umunsi: ${dayItem.fullDate} (${dayItem.dayLabel})",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "${dayItem.tripCount} trips",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("Yinjiye (+)", style = MaterialTheme.typography.labelSmall, color = MotoGreenSuccess)
                                        Text(Formatters.formatFrw(dayItem.incomeFrw), fontWeight = FontWeight.Bold)
                                    }

                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Yasohotse (-)", style = MaterialTheme.typography.labelSmall, color = MotoRedExpense)
                                        Text(Formatters.formatFrw(dayItem.expenseFrw), fontWeight = FontWeight.Bold)
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Inyungu (Profit)", style = MaterialTheme.typography.labelSmall)
                                        Text(
                                            text = Formatters.formatFrw(dayItem.netProfitFrw),
                                            fontWeight = FontWeight.Bold,
                                            color = if (dayItem.netProfitFrw >= 0) MotoGreenSuccess else MotoRedExpense
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (selectedDayIndex == null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "💡 Kanda ku munsi ngo ubone ibisobanuro birambuye.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )

                    Text(
                        text = "Inyungu/Day Avg: ${Formatters.formatFrw(avgDailyProfit)}",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (avgDailyProfit >= 0) MotoGreenSuccess else MotoRedExpense
                    )
                }
            }
        }
    }
}
