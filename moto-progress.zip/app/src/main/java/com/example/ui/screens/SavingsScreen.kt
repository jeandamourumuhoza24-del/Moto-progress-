package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.SavingsEntity
import com.example.data.entity.SavingsGoalEntity
import com.example.data.entity.UserEntity
import com.example.ui.theme.MotoBlueInfo
import com.example.ui.theme.MotoGreenSuccess
import com.example.ui.theme.MotoRedExpense
import com.example.ui.theme.MotoYellowPrimary
import com.example.util.Formatters
import java.util.Calendar

@Composable
fun SavingsScreen(
    user: UserEntity,
    savings: List<SavingsEntity>,
    savingsGoals: List<SavingsGoalEntity> = emptyList(),
    onAddSavingsClick: () -> Unit,
    onAddGoalClick: () -> Unit,
    onContributeGoal: (SavingsGoalEntity) -> Unit,
    onEditGoalClick: () -> Unit,
    onDeleteSavings: (SavingsEntity) -> Unit,
    onDeleteGoal: (SavingsGoalEntity) -> Unit
) {
    val totalSaved = savings.sumOf {
        if (it.type == "DEPOSIT") it.amountFrw else -it.amountFrw
    }.coerceAtLeast(0.0)

    val goal = user.monthlyGoalFrw
    val remainingGoal = (goal - totalSaved).coerceAtLeast(0.0)
    val percentage = if (goal > 0) ((totalSaved / goal) * 100).toInt().coerceIn(0, 100) else 0

    val cal = Calendar.getInstance()
    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val currentDay = cal.get(Calendar.DAY_OF_MONTH)
    val remainingDays = (daysInMonth - currentDay).coerceAtLeast(1)
    val dailyNeeded = if (remainingGoal > 0) remainingGoal / remainingDays else 0.0

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddSavingsClick,
                containerColor = MotoYellowPrimary,
                contentColor = Color.Black,
                icon = { Icon(Icons.Default.Add, contentDescription = "Kuzigama") },
                text = { Text("Kuzigama / Gukuramo", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("fab_add_savings")
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Kuzigama",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Kwiyubaka no gutegura ejo hazaza hawe",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                        )
                    }

                    IconButton(
                        onClick = onEditGoalClick,
                        modifier = Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Goal", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            // Monthly Goal Hero Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Intego y'Ukwezi: ${Formatters.formatFrw(goal)}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Surface(
                                color = if (percentage >= 100) MotoGreenSuccess else MotoYellowPrimary,
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text(
                                    text = "$percentage%",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color.Black
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        LinearProgressIndicator(
                            progress = { (percentage / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(12.dp)
                                .clip(RoundedCornerShape(6.dp)),
                            color = MotoYellowPrimary,
                            trackColor = MaterialTheme.colorScheme.surface
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Ayo wazigamye", style = MaterialTheme.typography.labelSmall)
                                Text(
                                    Formatters.formatFrw(totalSaved),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MotoGreenSuccess
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("Ayo ukeneye (Remaining)", style = MaterialTheme.typography.labelSmall)
                                Text(
                                    Formatters.formatFrw(remainingGoal),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (remainingGoal > 0) MotoRedExpense else MotoGreenSuccess
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Savings,
                                contentDescription = null,
                                tint = MotoYellowPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Kugira ngo ugere ku ntego, ukeneye kuzigama ${Formatters.formatFrw(dailyNeeded)}/day muri iyi minsi $remainingDays isigaye.",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Savings Goals Section (Motorcycle Repairs & Ownership Targets)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TwoWheeler, contentDescription = null, tint = MotoYellowPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Intego zo Gusana & Kugura Moto (${savingsGoals.size})",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    OutlinedButton(
                        onClick = onAddGoalClick,
                        modifier = Modifier.testTag("add_savings_goal_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Shyiraho Intego")
                    }
                }
            }

            if (savingsGoals.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "Nta ntego yo gusana moto cyangwa kuyigura irashyirwaho. Kanda 'Shyiraho Intego' utangire!",
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }
            } else {
                items(savingsGoals) { goalItem ->
                    val goalProgress = if (goalItem.targetAmountFrw > 0) {
                        (goalItem.currentAmountFrw / goalItem.targetAmountFrw).toFloat().coerceIn(0f, 1f)
                    } else 0f
                    val goalPercentInt = (goalProgress * 100).toInt()
                    val remainingFrw = (goalItem.targetAmountFrw - goalItem.currentAmountFrw).coerceAtLeast(0.0)

                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("savings_goal_card_${goalItem.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (goalItem.isCompleted) MotoGreenSuccess.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = if (goalItem.category == "OWNERSHIP") MotoYellowPrimary else MotoBlueInfo,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = if (goalItem.category == "OWNERSHIP") "KUGURA MOTO" else "GUSANA MOTO",
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = Color.Black
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = goalItem.title,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                }

                                IconButton(onClick = { onDeleteGoal(goalItem) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Goal", tint = MaterialTheme.colorScheme.error)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${Formatters.formatFrw(goalItem.currentAmountFrw)} / ${Formatters.formatFrw(goalItem.targetAmountFrw)}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "$goalPercentInt%",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (goalItem.isCompleted) MotoGreenSuccess else MotoYellowPrimary
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            LinearProgressIndicator(
                                progress = { goalProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = if (goalItem.isCompleted) MotoGreenSuccess else MotoYellowPrimary,
                                trackColor = MaterialTheme.colorScheme.surface
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (goalItem.isCompleted) "Intego yarangiye! 🎉" else "Hasigaye: ${Formatters.formatFrw(remainingFrw)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (goalItem.isCompleted) MotoGreenSuccess else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )

                                if (!goalItem.isCompleted) {
                                    Button(
                                        onClick = { onContributeGoal(goalItem) },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MotoYellowPrimary, contentColor = Color.Black),
                                        modifier = Modifier.testTag("contribute_goal_button_${goalItem.id}")
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Ongera", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // General Savings History
            item {
                Text(
                    text = "Amateka y'Ibyazigamwe (${savings.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            if (savings.isEmpty()) {
                item {
                    Text(
                        text = "Nta gwaso cyangwa kuzigama kurabaho.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            } else {
                items(savings) { item ->
                    val isDeposit = item.type == "DEPOSIT"
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier.size(40.dp).clip(CircleShape)
                                        .background(if (isDeposit) MotoGreenSuccess.copy(alpha = 0.15f) else MotoRedExpense.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Savings,
                                        contentDescription = null,
                                        tint = if (isDeposit) MotoGreenSuccess else MotoRedExpense
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (isDeposit) "Kuzigama (+)" else "Gukuramo (-)",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = Formatters.formatDateShort(item.dateMillis),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                    if (item.notes.isNotBlank()) {
                                        Text(
                                            text = item.notes,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }

                            Text(
                                text = "${if (isDeposit) "+" else "-"}${Formatters.formatFrw(item.amountFrw)}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (isDeposit) MotoGreenSuccess else MotoRedExpense
                            )
                        }
                    }
                }
            }
        }
    }
}
