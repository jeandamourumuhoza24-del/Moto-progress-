package com.example.ui.components

import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag

enum class MotoScreen(
    val titleKinyarwanda: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    AHABANZA("Ahabanza", Icons.Filled.Home, Icons.Outlined.Home),
    AMAFARANGA("Amafaranga", Icons.Filled.TrendingUp, Icons.Outlined.TrendingUp),
    YASOHOTSE("Yasohotse", Icons.Filled.TrendingDown, Icons.Outlined.TrendingDown),
    KUZIGAMA("Kuzigama", Icons.Filled.Savings, Icons.Outlined.Savings),
    MOTO("Moto", Icons.Filled.TwoWheeler, Icons.Outlined.TwoWheeler),
    IRAPORO("Iraporo", Icons.Filled.BarChart, Icons.Outlined.BarChart),
    PROFILE("Profile", Icons.Filled.Person, Icons.Outlined.Person)
}

@Composable
fun MotoBottomBar(
    currentScreen: MotoScreen,
    onScreenSelected: (MotoScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val bottomNavItems = listOf(
        MotoScreen.AHABANZA,
        MotoScreen.AMAFARANGA,
        MotoScreen.YASOHOTSE,
        MotoScreen.KUZIGAMA,
        MotoScreen.MOTO
    )

    NavigationBar(
        modifier = modifier.navigationBarsPadding(),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = NavigationBarDefaults.Elevation
    ) {
        bottomNavItems.forEach { screen ->
            val isSelected = currentScreen == screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onScreenSelected(screen) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                        contentDescription = screen.titleKinyarwanda
                    )
                },
                label = {
                    Text(
                        text = screen.titleKinyarwanda,
                        style = MaterialTheme.typography.labelMedium
                    )
                },
                modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
            )
        }
    }
}
