package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MotoYellowPrimary,
    onPrimary = Color.Black,
    primaryContainer = MotoYellowDark,
    onPrimaryContainer = Color.White,
    secondary = MotoTealAccent,
    onSecondary = Color.White,
    tertiary = MotoBlueInfo,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = DarkCardBg,
    onBackground = Color.White,
    onSurface = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = MotoYellowDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFEF08A),
    onPrimaryContainer = Color(0xFF713F12),
    secondary = MotoTealAccent,
    onSecondary = Color.White,
    tertiary = MotoBlueInfo,
    background = LightBackground,
    surface = LightSurface,
    surfaceVariant = LightCardBg,
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A)
)

@Composable
fun MotoProgressTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MotoProgressTheme(darkTheme = darkTheme, content = content)
}

