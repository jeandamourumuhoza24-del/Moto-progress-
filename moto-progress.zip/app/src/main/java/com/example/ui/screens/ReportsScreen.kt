package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.entity.ExpenseEntity
import com.example.data.entity.SavingsEntity
import com.example.data.entity.TripEntity
import com.example.data.entity.UserEntity
import com.example.ui.components.BarChartItem
import com.example.ui.components.DailyIncomeExpenseChart
import com.example.ui.theme.MotoGreenSuccess
import com.example.ui.theme.MotoRedExpense
import com.example.ui.theme.MotoTealAccent
import com.example.ui.theme.MotoYellowPrimary
import com.example.util.Formatters
import java.util.Calendar

@Composable
fun ReportsScreen(
    user: UserEntity,
    trips: List<TripEntity>,
    expenses: List<ExpenseEntity>,
    savings: List<SavingsEntity>
) {
    val now = System.currentTimeMillis()

    // Income calculations
    val todayIncome = trips.filter { Formatters.isSameDay(it.dateMillis, now) }.sumOf { it.amountFrw }
    val weekIncome = trips.filter { Formatters.isThisWeek(it.dateMillis) }.sumOf { it.amountFrw }
    val monthIncome = trips.filter { Formatters.isThisMonth(it.dateMillis) }.sumOf { it.amountFrw }
    val yearIncome = trips.filter { Formatters.isThisYear(it.dateMillis) }.sumOf { it.amountFrw }

    // Expense calculations
    val todayExpenses = expenses.filter { Formatters.isSameDay(it.dateMillis, now) }.sumOf { it.amountFrw }
    val weekExpenses = expenses.filter { Formatters.isThisWeek(it.dateMillis) }.sumOf { it.amountFrw }
    val monthExpenses = expenses.filter { Formatters.isThisMonth(it.dateMillis) }.sumOf { it.amountFrw }
    val yearExpenses = expenses.filter { Formatters.isThisYear(it.dateMillis) }.sumOf { it.amountFrw }

    // Profit calculations
    val todayProfit = todayIncome - todayExpenses
    val weekProfit = weekIncome - weekExpenses
    val monthProfit = monthIncome - monthExpenses
    val yearProfit = yearIncome - yearExpenses

    // Total Savings
    val totalSavings = savings.sumOf { if (it.type == "DEPOSIT") it.amountFrw else -it.amountFrw }.coerceAtLeast(0.0)

    // Best earning day
    val bestEarningDay = trips
        .groupBy { Formatters.formatDateShort(it.dateMillis) }
        .mapValues { entry -> entry.value.sumOf { it.amountFrw } }
        .maxByOrNull { it.value }

    // Highest expense category
    val highestExpenseCategory = expenses
        .groupBy { it.category }
        .mapValues { entry -> entry.value.sumOf { it.amountFrw } }
        .maxByOrNull { it.value }

    // Advice
    val adviceList = remember(trips, expenses, user.monthlyGoalFrw, totalSavings) {
        Formatters.generateSmartAdvice(trips, expenses, user.monthlyGoalFrw, totalSavings)
    }

    // Prepare Last 7 days chart items
    val last7DaysChartItems = remember(trips, expenses) {
        val list = mutableListOf<BarChartItem>()
        val cal = Calendar.getInstance()
        val dayNames = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        for (i in 6 downTo 0) {
            val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
            val dayMills = c.timeInMillis
            val inc = trips.filter { Formatters.isSameDay(it.dateMillis, dayMills) }.sumOf { it.amountFrw }
            val dayLabel = dayNames[c.get(Calendar.DAY_OF_WEEK) - 1]
            list.add(BarChartItem(label = dayLabel, value = inc, color = MotoYellowPrimary))
        }
        list
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Iraporo & Inama",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Incamake y'uburyo umutungo wawe uhagaze",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
        }

        // Smart Financial Advisor Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MotoTealAccent.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MotoTealAccent,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Inama y'uyu munsi (Smart Advisor)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (adviceList.isNotEmpty()) {
                        adviceList.forEach { advice ->
                            Row(
                                modifier = Modifier.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text("• ", fontWeight = FontWeight.Bold, color = MotoTealAccent)
                                Text(
                                    text = advice,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "Andika ingendo n'amafaranga nasohoye kugira ngo ubone inama z'ikoranabuhanga.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }

        // Profit Summary Table / Cards
        item {
            Text(
                text = "Inyungu Isigaye (Profit = Income - Expenses)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Uyu munsi", style = MaterialTheme.typography.labelSmall)
                            Text(Formatters.formatFrw(todayProfit), fontWeight = FontWeight.Bold, color = if (todayProfit >= 0) MotoGreenSuccess else MotoRedExpense)
                        }
                    }
                    Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Icyumweru", style = MaterialTheme.typography.labelSmall)
                            Text(Formatters.formatFrw(weekProfit), fontWeight = FontWeight.Bold, color = if (weekProfit >= 0) MotoGreenSuccess else MotoRedExpense)
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Ukwezi", style = MaterialTheme.typography.labelSmall)
                            Text(Formatters.formatFrw(monthProfit), fontWeight = FontWeight.Bold, color = if (monthProfit >= 0) MotoGreenSuccess else MotoRedExpense)
                        }
                    }
                    Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Umwaka", style = MaterialTheme.typography.labelSmall)
                            Text(Formatters.formatFrw(yearProfit), fontWeight = FontWeight.Bold, color = if (yearProfit >= 0) MotoGreenSuccess else MotoRedExpense)
                        }
                    }
                }
            }
        }

        // Daily Income vs Expense Visualization Chart
        item {
            DailyIncomeExpenseChart(trips = trips, expenses = expenses)
        }

        // Statistics Highlights
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Ibyaranzwe N'Ubucuruzi Bwawe",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Umunsi w'Urugendo rw'Inyungu cyane:", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = if (bestEarningDay != null) "${bestEarningDay.key} (${Formatters.formatFrw(bestEarningDay.value)})" else "Nta fishi",
                            fontWeight = FontWeight.Bold,
                            color = MotoGreenSuccess
                        )
                    }

                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Aho wakoresheje amafaranga menshi:", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = if (highestExpenseCategory != null) "${highestExpenseCategory.key} (${Formatters.formatFrw(highestExpenseCategory.value)})" else "Nta fishi",
                            fontWeight = FontWeight.Bold,
                            color = MotoRedExpense
                        )
                    }

                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Amafaranga yose ari mu kigega:", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = Formatters.formatFrw(totalSavings),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}
