package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.entity.*
import com.example.data.repository.MotoRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

data class MotoUiState(
    val currentUser: UserEntity? = null,
    val isLoading: Boolean = true,
    val authError: String? = null,
    val isAuthSuccess: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class)
class MotoViewModel(private val repository: MotoRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(MotoUiState())
    val uiState: StateFlow<MotoUiState> = _uiState.asStateFlow()

    private val _currentUserId = MutableStateFlow<Int?>(null)

    val trips: StateFlow<List<TripEntity>> = _currentUserId.flatMapLatest { userId ->
        if (userId != null) repository.getAllTrips(userId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenses: StateFlow<List<ExpenseEntity>> = _currentUserId.flatMapLatest { userId ->
        if (userId != null) repository.getAllExpenses(userId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savings: StateFlow<List<SavingsEntity>> = _currentUserId.flatMapLatest { userId ->
        if (userId != null) repository.getAllSavings(userId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val maintenance: StateFlow<List<MaintenanceEntity>> = _currentUserId.flatMapLatest { userId ->
        if (userId != null) repository.getAllMaintenance(userId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reminders: StateFlow<List<ReminderEntity>> = _currentUserId.flatMapLatest { userId ->
        if (userId != null) repository.getAllReminders(userId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val debts: StateFlow<List<DebtEntity>> = _currentUserId.flatMapLatest { userId ->
        if (userId != null) repository.getAllDebts(userId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savingsGoals: StateFlow<List<SavingsGoalEntity>> = _currentUserId.flatMapLatest { userId ->
        if (userId != null) repository.getAllSavingsGoals(userId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        checkLastUser()
    }

    private fun checkLastUser() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val lastUser = repository.getLastLoggedInUser()
            if (lastUser != null) {
                _currentUserId.value = lastUser.id
                _uiState.update { it.copy(currentUser = lastUser, isLoading = false) }
            } else {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    fun signUp(fullName: String, phone: String, pin: String, plate: String, monthlyGoal: Double) {
        viewModelScope.launch {
            if (fullName.isBlank() || phone.isBlank() || pin.isBlank()) {
                _uiState.update { it.copy(authError = "Nyamuneka uzuze imyirondoro yose neza.") }
                return@launch
            }
            val existing = repository.getUserByPhone(phone)
            if (existing != null) {
                _uiState.update { it.copy(authError = "Iyi nimero ya terefone ejo yarazamuwe. Injira aho kwandikisha.") }
                return@launch
            }

            val newUser = UserEntity(
                fullName = fullName,
                phoneNumber = phone,
                pinCode = pin,
                plateNumber = plate,
                monthlyGoalFrw = if (monthlyGoal > 0) monthlyGoal else 300000.0,
                currentOdometerKm = 15200
            )
            val newId = repository.insertUser(newUser).toInt()
            val savedUser = newUser.copy(id = newId)

            // Seed initial realistic driver data so user has immediate rich charts & advice
            seedSampleDataForUser(newId)

            _currentUserId.value = newId
            _uiState.update { it.copy(currentUser = savedUser, authError = null, isAuthSuccess = true) }
        }
    }

    fun login(phone: String, pin: String) {
        viewModelScope.launch {
            if (phone.isBlank() || pin.isBlank()) {
                _uiState.update { it.copy(authError = "Andika nimero ya terefone n'umubare w'ibanga (PIN).") }
                return@launch
            }
            val user = repository.getUserByPhone(phone)
            if (user == null || user.pinCode != pin) {
                _uiState.update { it.copy(authError = "Nimero ya terefone cyangwa PIN si byo. Gerageza tena.") }
                return@launch
            }
            _currentUserId.value = user.id
            _uiState.update { it.copy(currentUser = user, authError = null, isAuthSuccess = true) }
        }
    }

    fun logout() {
        _currentUserId.value = null
        _uiState.update { it.copy(currentUser = null, isAuthSuccess = false) }
    }

    fun clearAuthError() {
        _uiState.update { it.copy(authError = null) }
    }

    private suspend fun seedSampleDataForUser(userId: Int) {
        val now = System.currentTimeMillis()
        val oneDay = 24 * 60 * 60 * 1000L

        // Today's trips
        repository.insertTrip(TripEntity(userId = userId, amountFrw = 1500.0, dateMillis = now - 1000000, timeString = "07:30", pickupLocation = "Remera", dropoffLocation = "Nyabugogo", notes = "Umugenzi ufite umuzigo"))
        repository.insertTrip(TripEntity(userId = userId, amountFrw = 2000.0, dateMillis = now - 500000, timeString = "09:15", pickupLocation = "Nyabugogo", dropoffLocation = "Kacyiru", notes = "Urwego rwa leta"))
        repository.insertTrip(TripEntity(userId = userId, amountFrw = 1000.0, dateMillis = now - 100000, timeString = "11:00", pickupLocation = "Kacyiru", dropoffLocation = "Kimironko", notes = "Icyiciro gito"))

        // Yesterday's trips
        val yesterday = now - oneDay
        repository.insertTrip(TripEntity(userId = userId, amountFrw = 2500.0, dateMillis = yesterday, timeString = "08:00", pickupLocation = "Kicukiro", dropoffLocation = "Town", notes = "Saa sita"))
        repository.insertTrip(TripEntity(userId = userId, amountFrw = 3000.0, dateMillis = yesterday, timeString = "14:20", pickupLocation = "Town", dropoffLocation = "Giporoso", notes = "Urugendo ruderby"))

        // Expenses
        repository.insertExpense(ExpenseEntity(userId = userId, category = "Lisansi", amountFrw = 3500.0, dateMillis = now, notes = "Lisansi yo ku mugoroba"))
        repository.insertExpense(ExpenseEntity(userId = userId, category = "Food", amountFrw = 1200.0, dateMillis = now, notes = "Ibyo kurya ku manywa"))
        repository.insertExpense(ExpenseEntity(userId = userId, category = "Parking", amountFrw = 300.0, dateMillis = now, notes = "Guhagarara mu mugi"))
        repository.insertExpense(ExpenseEntity(userId = userId, category = "Lisansi", amountFrw = 4000.0, dateMillis = yesterday, notes = "Station SP"))

        // Savings
        repository.insertSavings(SavingsEntity(userId = userId, type = "DEPOSIT", amountFrw = 50000.0, dateMillis = now - (3 * oneDay), notes = "Kuzigama icyumweru gishize"))
        repository.insertSavings(SavingsEntity(userId = userId, type = "DEPOSIT", amountFrw = 30000.0, dateMillis = now, notes = "Kuzigama uyu munsi"))

        // Maintenance
        repository.insertMaintenance(MaintenanceEntity(userId = userId, type = "Amavuta ya moto", dateMillis = now - (10 * oneDay), odometerKm = 14800, costFrw = 6000.0, nextDueKm = 16000, nextDueDateMillis = now + (15 * oneDay), notes = "Amavuta ya Castrol"))
        repository.insertMaintenance(MaintenanceEntity(userId = userId, type = "Amapine", dateMillis = now - (30 * oneDay), odometerKm = 14000, costFrw = 28000.0, nextDueKm = 20000, nextDueDateMillis = now + (90 * oneDay), notes = "Ipine ry'inyuma"))

        // Reminders
        repository.insertReminder(ReminderEntity(userId = userId, title = "Guhindura amavuta ya moto", category = "Amavuta", dueDateMillis = now + (2 * oneDay), notes = "Irometero 16,000 km"))
        repository.insertReminder(ReminderEntity(userId = userId, title = "Kuzigama 10,000 Frw muri Ejo Heza", category = "Kuzigama", dueDateMillis = now + (1 * oneDay), notes = "Intego y'ukwezi"))
        repository.insertReminder(ReminderEntity(userId = userId, title = "Kwishyura Ibibina / Insurance", category = "Ibibina/Bills", dueDateMillis = now + (5 * oneDay), amountFrw = 15000.0, notes = "Mutuelle / Insurance moto"))

        // Debts
        repository.insertDebt(DebtEntity(userId = userId, personName = "Karisa (Mechanic)", type = "I_OWE", amountFrw = 8000.0, dueDateMillis = now + (3 * oneDay), notes = "Kugura feri nshya"))
        repository.insertDebt(DebtEntity(userId = userId, personName = "Mukamana (Umugenzi)", type = "OWES_ME", amountFrw = 3500.0, dueDateMillis = now + (1 * oneDay), notes = "Kwizera ikoranabuhanga Mobile Money"))

        // Savings Goals
        repository.insertSavingsGoal(
            SavingsGoalEntity(
                userId = userId,
                title = "Gusana Moteur na Pneu (Repairs)",
                targetAmountFrw = 150000.0,
                currentAmountFrw = 60000.0,
                targetDateMillis = now + (30 * oneDay),
                category = "REPAIR",
                notes = "Gusana no guhindura ibipfunsi n'amapneu"
            )
        )
        repository.insertSavingsGoal(
            SavingsGoalEntity(
                userId = userId,
                title = "Kugura Moto Yanjye Bwite (Ownership)",
                targetAmountFrw = 1800000.0,
                currentAmountFrw = 450000.0,
                targetDateMillis = now + (180 * oneDay),
                category = "OWNERSHIP",
                notes = "Kuva mu gukodesha nkagura moto yanjye bwite"
            )
        )
    }

    // Actions
    fun addTrip(amount: Double, pickup: String, dropoff: String, notes: String, dateMillis: Long = System.currentTimeMillis(), timeStr: String = "") {
        val userId = _currentUserId.value ?: return
        val cal = Calendar.getInstance()
        val timeFormatted = if (timeStr.isNotBlank()) timeStr else String.format("%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))
        viewModelScope.launch {
            repository.insertTrip(
                TripEntity(
                    userId = userId,
                    amountFrw = amount,
                    dateMillis = dateMillis,
                    timeString = timeFormatted,
                    pickupLocation = pickup.ifBlank { "Kigali" },
                    dropoffLocation = dropoff.ifBlank { "Kigali" },
                    notes = notes
                )
            )
        }
    }

    fun deleteTrip(trip: TripEntity) {
        viewModelScope.launch {
            repository.deleteTrip(trip)
        }
    }

    fun addExpense(category: String, amount: Double, notes: String, dateMillis: Long = System.currentTimeMillis()) {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            repository.insertExpense(
                ExpenseEntity(
                    userId = userId,
                    category = category,
                    amountFrw = amount,
                    dateMillis = dateMillis,
                    notes = notes
                )
            )
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
        }
    }

    fun addSavings(type: String, amount: Double, notes: String) {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            repository.insertSavings(
                SavingsEntity(
                    userId = userId,
                    type = type,
                    amountFrw = amount,
                    dateMillis = System.currentTimeMillis(),
                    notes = notes
                )
            )
        }
    }

    fun deleteSavings(savings: SavingsEntity) {
        viewModelScope.launch {
            repository.deleteSavings(savings)
        }
    }

    fun updateMonthlyGoal(newGoal: Double) {
        val user = _uiState.value.currentUser ?: return
        viewModelScope.launch {
            val updated = user.copy(monthlyGoalFrw = newGoal)
            repository.updateUser(updated)
            _uiState.update { it.copy(currentUser = updated) }
        }
    }

    fun addMaintenance(type: String, cost: Double, odometer: Int, nextKm: Int, notes: String) {
        val userId = _currentUserId.value ?: return
        val now = System.currentTimeMillis()
        viewModelScope.launch {
            repository.insertMaintenance(
                MaintenanceEntity(
                    userId = userId,
                    type = type,
                    dateMillis = now,
                    odometerKm = odometer,
                    costFrw = cost,
                    nextDueKm = nextKm,
                    nextDueDateMillis = now + (30L * 24 * 60 * 60 * 1000),
                    notes = notes
                )
            )
            // Also update current odometer in user profile
            _uiState.value.currentUser?.let { u ->
                if (odometer > u.currentOdometerKm) {
                    val updatedU = u.copy(currentOdometerKm = odometer)
                    repository.updateUser(updatedU)
                    _uiState.update { it.copy(currentUser = updatedU) }
                }
            }
            // Auto create reminder for next service
            if (nextKm > 0) {
                repository.insertReminder(
                    ReminderEntity(
                        userId = userId,
                        title = "Service ya Moto ($type)",
                        category = type,
                        dueDateMillis = now + (14L * 24 * 60 * 60 * 1000),
                        notes = "Uzagera ku kilometero $nextKm km"
                    )
                )
            }
        }
    }

    fun addReminder(title: String, category: String, daysFromNow: Int, amount: Double = 0.0, notes: String = "") {
        val userId = _currentUserId.value ?: return
        val due = System.currentTimeMillis() + (daysFromNow * 24 * 60 * 60 * 1000L)
        viewModelScope.launch {
            repository.insertReminder(
                ReminderEntity(
                    userId = userId,
                    title = title,
                    category = category,
                    dueDateMillis = due,
                    amountFrw = amount,
                    notes = notes
                )
            )
        }
    }

    fun toggleReminderCompleted(reminder: ReminderEntity) {
        viewModelScope.launch {
            repository.updateReminder(reminder.copy(isCompleted = !reminder.isCompleted))
        }
    }

    fun deleteReminder(reminder: ReminderEntity) {
        viewModelScope.launch {
            repository.deleteReminder(reminder)
        }
    }

    fun addDebt(personName: String, type: String, amount: Double, daysFromNow: Int, notes: String) {
        val userId = _currentUserId.value ?: return
        val due = System.currentTimeMillis() + (daysFromNow * 24 * 60 * 60 * 1000L)
        viewModelScope.launch {
            repository.insertDebt(
                DebtEntity(
                    userId = userId,
                    personName = personName,
                    type = type,
                    amountFrw = amount,
                    dueDateMillis = due,
                    notes = notes
                )
            )
        }
    }

    fun toggleDebtPaid(debt: DebtEntity) {
        viewModelScope.launch {
            repository.updateDebt(debt.copy(isPaid = !debt.isPaid))
        }
    }

    fun deleteDebt(debt: DebtEntity) {
        viewModelScope.launch {
            repository.deleteDebt(debt)
        }
    }

    // Savings Goals Methods (Motorcycle Repairs & Ownership)
    fun addSavingsGoal(
        title: String,
        targetAmount: Double,
        initialAmount: Double = 0.0,
        daysFromNow: Int = 60,
        category: String = "REPAIR",
        notes: String = ""
    ) {
        val userId = _currentUserId.value ?: return
        val targetDate = System.currentTimeMillis() + (daysFromNow * 24 * 60 * 60 * 1000L)
        viewModelScope.launch {
            repository.insertSavingsGoal(
                SavingsGoalEntity(
                    userId = userId,
                    title = title,
                    targetAmountFrw = targetAmount,
                    currentAmountFrw = initialAmount,
                    targetDateMillis = targetDate,
                    category = category,
                    isCompleted = initialAmount >= targetAmount,
                    notes = notes
                )
            )
        }
    }

    fun contributeToSavingsGoal(goal: SavingsGoalEntity, amount: Double) {
        val newCurrent = goal.currentAmountFrw + amount
        val updatedGoal = goal.copy(
            currentAmountFrw = newCurrent,
            isCompleted = newCurrent >= goal.targetAmountFrw
        )
        viewModelScope.launch {
            repository.updateSavingsGoal(updatedGoal)
            // Also add a deposit entry to general savings flow
            repository.insertSavings(
                SavingsEntity(
                    userId = goal.userId,
                    type = "DEPOSIT",
                    amountFrw = amount,
                    dateMillis = System.currentTimeMillis(),
                    notes = "Intego: ${goal.title}"
                )
            )
        }
    }

    fun updateSavingsGoal(goal: SavingsGoalEntity) {
        viewModelScope.launch {
            repository.updateSavingsGoal(goal)
        }
    }

    fun deleteSavingsGoal(goal: SavingsGoalEntity) {
        viewModelScope.launch {
            repository.deleteSavingsGoal(goal)
        }
    }
}

class MotoViewModelFactory(private val repository: MotoRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MotoViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MotoViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
