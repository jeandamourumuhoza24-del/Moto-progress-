package com.example.util

import com.example.data.entity.ExpenseEntity
import com.example.data.entity.TripEntity
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

object Formatters {

    fun formatFrw(amount: Double): String {
        val formatter = NumberFormat.getNumberInstance(Locale.US)
        formatter.maximumFractionDigits = 0
        return "${formatter.format(amount)} Frw"
    }

    fun formatDateShort(timeMillis: Long): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        return sdf.format(Date(timeMillis))
    }

    fun formatDateKinyarwanda(timeMillis: Long): String {
        val cal = Calendar.getInstance()
        cal.timeInMillis = timeMillis
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val monthNames = arrayOf(
            "Mutarama", "Gashyantare", "Werurwe", "Mata", "Gicurasi", "Kamena",
            "Mulyango", "Agustus", "Nzeri", "Ukwakira", "Ugushyingo", "Ukutsina"
        )
        val month = monthNames[cal.get(Calendar.MONTH)]
        val year = cal.get(Calendar.YEAR)
        return "$day $month $year"
    }

    fun isSameDay(time1: Long, time2: Long): Boolean {
        val cal1 = Calendar.getInstance().apply { timeInMillis = time1 }
        val cal2 = Calendar.getInstance().apply { timeInMillis = time2 }
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
    }

    fun isThisWeek(timeMillis: Long): Boolean {
        val cal = Calendar.getInstance()
        val currentWeek = cal.get(Calendar.WEEK_OF_YEAR)
        val currentYear = cal.get(Calendar.YEAR)

        val targetCal = Calendar.getInstance().apply { timeInMillis = timeMillis }
        return targetCal.get(Calendar.WEEK_OF_YEAR) == currentWeek &&
                targetCal.get(Calendar.YEAR) == currentYear
    }

    fun isThisMonth(timeMillis: Long): Boolean {
        val cal = Calendar.getInstance()
        val currentMonth = cal.get(Calendar.MONTH)
        val currentYear = cal.get(Calendar.YEAR)

        val targetCal = Calendar.getInstance().apply { timeInMillis = timeMillis }
        return targetCal.get(Calendar.MONTH) == currentMonth &&
                targetCal.get(Calendar.YEAR) == currentYear
    }

    fun isThisYear(timeMillis: Long): Boolean {
        val cal = Calendar.getInstance()
        val currentYear = cal.get(Calendar.YEAR)

        val targetCal = Calendar.getInstance().apply { timeInMillis = timeMillis }
        return targetCal.get(Calendar.YEAR) == currentYear
    }

    fun generateSmartAdvice(
        trips: List<TripEntity>,
        expenses: List<ExpenseEntity>,
        monthlyGoalFrw: Double,
        currentSavedFrw: Double
    ): List<String> {
        val adviceList = mutableListOf<String>()
        val now = System.currentTimeMillis()

        val todayTrips = trips.filter { isSameDay(it.dateMillis, now) }
        val todayIncome = todayTrips.sumOf { it.amountFrw }

        val yesterdayCal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -1)
        }
        val yesterdayTrips = trips.filter { isSameDay(it.dateMillis, yesterdayCal.timeInMillis) }
        val yesterdayIncome = yesterdayTrips.sumOf { it.amountFrw }

        // Comparison advice
        if (todayTrips.isNotEmpty() && yesterdayTrips.isNotEmpty()) {
            if (todayIncome > yesterdayIncome) {
                adviceList.add("Uyu munsi winjije amafaranga menshi kurusha ejo (${formatFrw(todayIncome)} vs ${formatFrw(yesterdayIncome)}). Komeza neza!")
            } else if (todayIncome < yesterdayIncome) {
                adviceList.add("Ejo wari winjije amafaranga menshi kurusha uyu munsi. Shaka abagenzi benshi!")
            } else {
                adviceList.add("Winjije amafaranga angana n'ayo wowe winjije ejo (${formatFrw(todayIncome)}).")
            }
        } else if (todayTrips.isNotEmpty()) {
            adviceList.add("Uyu munsi amaze gukora urugendo ${todayTrips.size}, urinjiza ${formatFrw(todayIncome)}.")
        } else {
            adviceList.add("Nta rugendo turandika uyu munsi. Bika ingendo zawe hano maze urebe inyungu!")
        }

        // Fuel and Expenses advice
        val todayExpenses = expenses.filter { isSameDay(it.dateMillis, now) }
        val todayFuel = todayExpenses.filter { it.category.contains("Lisansi", ignoreCase = true) }.sumOf { it.amountFrw }
        val totalTodayExp = todayExpenses.sumOf { it.amountFrw }

        if (todayFuel > 0 && todayIncome > 0) {
            val fuelPercent = (todayFuel / todayIncome) * 100
            if (fuelPercent > 35) {
                adviceList.add("Lisansi iri gufata igice kinini cy'amafaranga yawe (${String.format(Locale.US, "%.1f", fuelPercent)}%). Gerageza kugendera ku muvuduko utunganye.")
            } else {
                adviceList.add("Igipimo cya lisansi kiri ku kigereranyo cyiza (${String.format(Locale.US, "%.1f", fuelPercent)}% by'ingano y'amafaranga winjije).")
            }
        }

        // Savings goal advice
        if (monthlyGoalFrw > 0) {
            val progressPercent = (currentSavedFrw / monthlyGoalFrw) * 100
            val remaining = monthlyGoalFrw - currentSavedFrw
            val cal = Calendar.getInstance()
            val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            val currentDay = cal.get(Calendar.DAY_OF_MONTH)
            val daysLeft = (daysInMonth - currentDay).coerceAtLeast(1)
            val dailyNeeded = if (remaining > 0) remaining / daysLeft else 0.0

            if (currentSavedFrw >= monthlyGoalFrw) {
                adviceList.add("Uri ku ntego! Wageze ku ntego yawe y'ukwezi y'amafaranga ${formatFrw(monthlyGoalFrw)}. Urashimwa!")
            } else {
                adviceList.add("Niba ukomeje kuzigama ${formatFrw(dailyNeeded)} buri munsi muri iyi minsi $daysLeft isigaye, uzagera ku ntego yawe y'ukwezi (${formatFrw(monthlyGoalFrw)}).")
            }
        }

        return adviceList
    }
}
