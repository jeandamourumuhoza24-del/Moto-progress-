package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.db.AppDatabase
import com.example.data.entity.SavingsGoalEntity
import com.example.data.repository.MotoRepository
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.MotoProgressTheme
import com.example.ui.viewmodel.MotoViewModel
import com.example.ui.viewmodel.MotoViewModelFactory

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext)
        val repository = MotoRepository(
            userDao = database.userDao(),
            tripDao = database.tripDao(),
            expenseDao = database.expenseDao(),
            savingsDao = database.savingsDao(),
            maintenanceDao = database.maintenanceDao(),
            reminderDao = database.reminderDao(),
            debtDao = database.debtDao(),
            savingsGoalDao = database.savingsGoalDao()
        )
        val viewModelFactory = MotoViewModelFactory(repository)

        setContent {
            MotoProgressTheme {
                val viewModel: MotoViewModel = viewModel(factory = viewModelFactory)
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                val trips by viewModel.trips.collectAsStateWithLifecycle()
                val expenses by viewModel.expenses.collectAsStateWithLifecycle()
                val savings by viewModel.savings.collectAsStateWithLifecycle()
                val maintenance by viewModel.maintenance.collectAsStateWithLifecycle()
                val reminders by viewModel.reminders.collectAsStateWithLifecycle()
                val debts by viewModel.debts.collectAsStateWithLifecycle()
                val savingsGoals by viewModel.savingsGoals.collectAsStateWithLifecycle()

                var currentScreen by remember { mutableStateOf(MotoScreen.AHABANZA) }

                // Dialog states
                var showAddTripDialog by remember { mutableStateOf(false) }
                var showAddExpenseDialog by remember { mutableStateOf(false) }
                var showAddSavingsDialog by remember { mutableStateOf(false) }
                var showAddSavingsGoalDialog by remember { mutableStateOf(false) }
                var selectedGoalForContribution by remember { mutableStateOf<SavingsGoalEntity?>(null) }
                var showEditGoalDialog by remember { mutableStateOf(false) }
                var showAddMaintenanceDialog by remember { mutableStateOf(false) }
                var showAddReminderDialog by remember { mutableStateOf(false) }
                var showAddDebtDialog by remember { mutableStateOf(false) }

                if (uiState.isLoading) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        CircularProgressIndicator()
                    }
                } else if (uiState.currentUser == null) {
                    AuthScreen(
                        onSignUp = { name, phone, pin, plate, goal ->
                            viewModel.signUp(name, phone, pin, plate, goal)
                        },
                        onLogin = { phone, pin ->
                            viewModel.login(phone, pin)
                        },
                        errorMsg = uiState.authError,
                        onClearError = { viewModel.clearAuthError() }
                    )
                } else {
                    val user = uiState.currentUser!!

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        topBar = {
                            OptInTopAppBar(
                                title = "Moto Progress",
                                onNavigateToReports = { currentScreen = MotoScreen.IRAPORO },
                                onNavigateToProfile = { currentScreen = MotoScreen.PROFILE }
                            )
                        },
                        bottomBar = {
                            MotoBottomBar(
                                currentScreen = currentScreen,
                                onScreenSelected = { currentScreen = it }
                            )
                        }
                    ) { innerPadding ->
                        Surface(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding),
                            color = MaterialTheme.colorScheme.background
                        ) {
                            when (currentScreen) {
                                MotoScreen.AHABANZA -> DashboardScreen(
                                    user = user,
                                    trips = trips,
                                    expenses = expenses,
                                    savings = savings,
                                    reminders = reminders,
                                    debts = debts,
                                    onAddTripClick = { showAddTripDialog = true },
                                    onAddExpenseClick = { showAddExpenseDialog = true },
                                    onToggleReminder = { viewModel.toggleReminderCompleted(it) },
                                    onNavigateToReports = { currentScreen = MotoScreen.IRAPORO },
                                    onNavigateToProfile = { currentScreen = MotoScreen.PROFILE }
                                )
                                MotoScreen.AMAFARANGA -> IncomeScreen(
                                    trips = trips,
                                    onAddTripClick = { showAddTripDialog = true },
                                    onDeleteTrip = { viewModel.deleteTrip(it) }
                                )
                                MotoScreen.YASOHOTSE -> ExpensesScreen(
                                    expenses = expenses,
                                    onAddExpenseClick = { showAddExpenseDialog = true },
                                    onDeleteExpense = { viewModel.deleteExpense(it) }
                                )
                                MotoScreen.KUZIGAMA -> SavingsScreen(
                                    user = user,
                                    savings = savings,
                                    savingsGoals = savingsGoals,
                                    onAddSavingsClick = { showAddSavingsDialog = true },
                                    onAddGoalClick = { showAddSavingsGoalDialog = true },
                                    onContributeGoal = { selectedGoalForContribution = it },
                                    onEditGoalClick = { showEditGoalDialog = true },
                                    onDeleteSavings = { viewModel.deleteSavings(it) },
                                    onDeleteGoal = { viewModel.deleteSavingsGoal(it) }
                                )
                                MotoScreen.MOTO -> MotoScreen(
                                    user = user,
                                    maintenanceList = maintenance,
                                    remindersList = reminders,
                                    debtsList = debts,
                                    onAddMaintenanceClick = { showAddMaintenanceDialog = true },
                                    onAddReminderClick = { showAddReminderDialog = true },
                                    onAddDebtClick = { showAddDebtDialog = true },
                                    onToggleReminder = { viewModel.toggleReminderCompleted(it) },
                                    onToggleDebtPaid = { viewModel.toggleDebtPaid(it) },
                                    onDeleteReminder = { viewModel.deleteReminder(it) },
                                    onDeleteDebt = { viewModel.deleteDebt(it) }
                                )
                                MotoScreen.IRAPORO -> ReportsScreen(
                                    user = user,
                                    trips = trips,
                                    expenses = expenses,
                                    savings = savings
                                )
                                MotoScreen.PROFILE -> ProfileScreen(
                                    user = user,
                                    onEditGoalClick = { showEditGoalDialog = true },
                                    onLogoutClick = { viewModel.logout() }
                                )
                            }
                        }
                    }

                    // Dialogs
                    if (showAddTripDialog) {
                        AddTripDialog(
                            onDismiss = { showAddTripDialog = false },
                            onSave = { amount, pickup, dropoff, notes ->
                                viewModel.addTrip(amount, pickup, dropoff, notes)
                            }
                        )
                    }

                    if (showAddExpenseDialog) {
                        AddExpenseDialog(
                            onDismiss = { showAddExpenseDialog = false },
                            onSave = { category, amount, notes ->
                                viewModel.addExpense(category, amount, notes)
                            }
                        )
                    }

                    if (showAddSavingsDialog) {
                        AddSavingsDialog(
                            onDismiss = { showAddSavingsDialog = false },
                            onSave = { type, amount, notes ->
                                viewModel.addSavings(type, amount, notes)
                            }
                        )
                    }

                    if (showAddSavingsGoalDialog) {
                        AddSavingsGoalDialog(
                            onDismiss = { showAddSavingsGoalDialog = false },
                            onSave = { title, targetAmt, initAmt, days, category, notes ->
                                viewModel.addSavingsGoal(title, targetAmt, initAmt, days, category, notes)
                            }
                        )
                    }

                    if (selectedGoalForContribution != null) {
                        val goal = selectedGoalForContribution!!
                        ContributeSavingsGoalDialog(
                            goalTitle = goal.title,
                            remainingAmountFrw = (goal.targetAmountFrw - goal.currentAmountFrw).coerceAtLeast(0.0),
                            onDismiss = { selectedGoalForContribution = null },
                            onSave = { amount ->
                                viewModel.contributeToSavingsGoal(goal, amount)
                            }
                        )
                    }

                    if (showEditGoalDialog) {
                        EditGoalDialog(
                            currentGoal = user.monthlyGoalFrw,
                            onDismiss = { showEditGoalDialog = false },
                            onSave = { newGoal ->
                                viewModel.updateMonthlyGoal(newGoal)
                            }
                        )
                    }

                    if (showAddMaintenanceDialog) {
                        AddMaintenanceDialog(
                            onDismiss = { showAddMaintenanceDialog = false },
                            onSave = { type, cost, odometer, nextKm, notes ->
                                viewModel.addMaintenance(type, cost, odometer, nextKm, notes)
                            }
                        )
                    }

                    if (showAddReminderDialog) {
                        AddReminderDialog(
                            onDismiss = { showAddReminderDialog = false },
                            onSave = { title, category, days, amount, notes ->
                                viewModel.addReminder(title, category, days, amount, notes)
                            }
                        )
                    }

                    if (showAddDebtDialog) {
                        AddDebtDialog(
                            onDismiss = { showAddDebtDialog = false },
                            onSave = { person, type, amount, days, notes ->
                                viewModel.addDebt(person, type, amount, days, notes)
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptInTopAppBar(
    title: String,
    onNavigateToReports: () -> Unit,
    onNavigateToProfile: () -> Unit
) {
    TopAppBar(
        title = { Text(text = title, fontWeight = FontWeight.Bold) },
        actions = {
            IconButton(onClick = onNavigateToReports) {
                Icon(Icons.Default.BarChart, contentDescription = "Iraporo")
            }
            IconButton(onClick = onNavigateToProfile) {
                Icon(Icons.Default.Person, contentDescription = "Profile")
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    )
}
